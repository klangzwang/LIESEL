import React from 'react';
import { Handle, NodeProps, Position } from '@xyflow/react';
import { useStatusStore } from 'store/StatusStore';
import { Route } from 'lucide-react';

//
// The FunctionNode, that are showing on the Grid
//
interface FunctionNodeProps extends React.HTMLAttributes<HTMLDivElement> {
  label?: string;
  selected?: boolean;
  children?: React.ReactNode;
  className?: string;
}

export const FunctionNode: React.FC<FunctionNodeProps> = ({
  label = "",
  selected,
  children,
  className = '',
  ...props
}) => {

  return (
    <div
      className={`flex w-full h-full bg-[#111] p-4 ${className}`}
      {...props}
    >
      {label}
      {children}
    </div>
  );
};

//
// The Nodes, that are showing in the LeftSideBar
//
interface SideBarNodeProps {
  type: string;
  label: string;
}

export const SideBarNode: React.FC<SideBarNodeProps> = ({
  type = '',
  label = '',
}) => {

  const { setText, clearText } = useStatusStore();

  const onDragStart = (event: React.DragEvent) => {
    event.dataTransfer.setData('application/reactflow', type);
    event.dataTransfer.effectAllowed = 'move';
  };

  return (
    <div
      draggable
      onDragStart={onDragStart}
      onMouseEnter={() => setText(`Drag ${label} to Canvas`)}
      onMouseLeave={() => clearText()}
      className="flex flex-row w-full h-full p-1"
    >
      <div className="flex items-center pr-2">
        <Route size={16} />
      </div>

      <div className='flex grow font-[Roboto] text-[0.8rem] text-[#d2d2d2] hover:text-[#fff] tracking-wide cursor-pointer transition-colors'>
        {label}
      </div>

    </div>
  );
};

// /////////////////////////////////////////////////////////////////////
//
//  SYSTEM NODES
//
// /////////////////////////////////////////////////////////////////////

export const GenerateNode = ({ selected }: NodeProps) => {
  return (
    <FunctionNode label='Generate'>
      <div className={`flex`}>
        <div className={`w-3 h-3 rounded-full bg-[#444] border-2 ${selected ? 'border-[#e2c27d]' : 'border-[#111]'} relative flex items-center justify-center`}>
          <Handle
            type="source"
            position={Position.Right}
            id="out"
            className="opacity-0 absolute w-full h-full inset-0 m-0 rounded-full"
          />
        </div>
      </div>

    </FunctionNode>
  );
};

export const RerouteNode = ({ selected }: NodeProps) => {
  return (
    <div className={`w-3 h-3 rounded-full bg-[#444] border-2 ${selected ? 'border-[#e2c27d]' : 'border-[#111]'} relative flex items-center justify-center`}>
      <Handle
        type="target"
        position={Position.Left}
        id="in"
        className="opacity-0 absolute w-full h-full inset-0 m-0 rounded-full"
      />
      <Handle
        type="source"
        position={Position.Right}
        id="out"
        className="opacity-0 absolute w-full h-full inset-0 m-0 rounded-full"
      />
    </div>
  );
};

// /////////////////////////////////////////////////////////////////////
//
//  FUNCTION NODES
//
// /////////////////////////////////////////////////////////////////////

export const TextOutputNode = ({ selected }: NodeProps) => {
  return (
    <FunctionNode label='TextOutput'>
      <div className={``}>
      </div>
    </FunctionNode>
  );
};