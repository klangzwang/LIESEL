import { createRoot } from 'react-dom/client';
import { MenuBar } from './components/MenuBar';
import { StatusBar } from './components/StatusBar';
import { RightSidebar } from './components/RightSideBar';
import { LeftSidebar } from './components/LeftSideBar';
import { FlowCanvas } from 'flow/FlowCanvas';
import { BootWidget } from 'llm/components/widgets/BootWidget';
import { useDocumentStore } from './store/DocumentStore';
import { useLLMEngine } from 'llm/hooks/useLLMEngine';
import { ReactFlowProvider } from '@xyflow/react';

import '@css/style.css';

if (typeof window !== 'undefined') {
  const originalErrorHandler = window.onerror;
  window.onerror = (message, source, lineno, colno, error) => {
    if (
      typeof message === 'string' &&
      (message.includes('ResizeObserver loop completed with undelivered notifications') ||
        message.includes('ResizeObserver loop limit exceeded'))
    ) {
      return true;
    }
    if (originalErrorHandler) {
      return originalErrorHandler(message, source, lineno, colno, error);
    }
    return false;
  };
}

export function Editor() {
  const documentId = useDocumentStore((state) => state.documentId);
  const engineState = useLLMEngine();

  return (
    <ReactFlowProvider>
      <div
        className="flex flex-col h-screen w-screen overflow-hidden bg-[#151515] text-slate-200 font-sans select-none"
        onContextMenu={(e) => e.preventDefault()}
        key={documentId}
      >
        {engineState.status !== 'ready' ?
          <div className="flex flex-1 overflow-hidden">
            <BootWidget engineState={engineState} />
          </div>
          :
          <>
            <MenuBar />
            <div className="flex flex-1 overflow-hidden">
              <LeftSidebar />
              <FlowCanvas />
              <RightSidebar />
            </div>
            <StatusBar />
          </>
        }
      </div>
    </ReactFlowProvider>
  );
}

const container = document.getElementById('root')!;
const root = (container as any)._reactRoot || createRoot(container);
(container as any)._reactRoot = root;
root.render(<Editor />);
