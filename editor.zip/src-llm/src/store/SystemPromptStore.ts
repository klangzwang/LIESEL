import { create } from 'zustand';

export const DEFAULT_SYSTEM_PROMPT = `You are an expert Prompt Engineer for AI image generators (such as Midjourney, Flux, and Stable Diffusion). Your task is to take a structured list of attributes and transform it into a single, cohesive, high-quality image generation prompt in English.

### RULES:
1. Incorporate ALL values provided in the input list. Do not omit any parameter.
2. Translate any non-English inputs into precise English descriptive terms.
3. Convert technical/abstract keywords into visual details (e.g., "Technical: Low-Poly" -> "low-poly 3D style, crisp faceted polygon surfaces, geometric mesh").
4. Structure the output prompt logically: [Subject & Material] in [Location/Environment], [Lighting], [Camera & Perspective], [Style & Aesthetics], [Color Palette], [Composition & Aspect Ratio].
5. Do NOT use generic buzzwords like "photorealistic", "hyperrealistic", or "4K". Describe the visual qualities instead.

### OUTPUT FORMAT:
Output ONLY the final image generation prompt inside a code block. Do not include any greetings, explanations, or conversational filler.`;

const STORAGE_KEY = 'llm-system-prompt';

interface SystemPromptState {
  systemPrompt: string;
  setSystemPrompt: (prompt: string) => void;
  resetSystemPrompt: () => void;
}

const getInitialPrompt = (): string => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved && saved.trim().length > 0) {
      return saved;
    }
  } catch (e) {
    console.error('Failed to load system prompt from storage', e);
  }
  return DEFAULT_SYSTEM_PROMPT;
};

export const useSystemPromptStore = create<SystemPromptState>((set) => ({
  systemPrompt: getInitialPrompt(),
  setSystemPrompt: (prompt: string) => {
    try {
      localStorage.setItem(STORAGE_KEY, prompt);
    } catch (e) {
      console.error('Failed to save system prompt', e);
    }
    set({ systemPrompt: prompt });
  },
  resetSystemPrompt: () => {
    try {
      localStorage.setItem(STORAGE_KEY, DEFAULT_SYSTEM_PROMPT);
    } catch (e) {
      console.error('Failed to reset system prompt', e);
    }
    set({ systemPrompt: DEFAULT_SYSTEM_PROMPT });
  },
}));
